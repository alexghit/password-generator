# Store assets

Listing images for the Chrome Web Store. Not deployed, not shipped in the
extension package.

| File | Size | Use |
|---|---|---|
| `screenshot-1280x800.png` | 1280×800 | Listing screenshot (required, min 1) |
| `promo-tile-440x280.png` | 440×280 | Small promo tile (required) |
| `marquee-1400x560.png` | 1400×560 | Marquee tile (optional) |

The 128×128 store icon is `extension/icon128.png`.

All are flat RGB PNGs with no alpha, which the store requires.
